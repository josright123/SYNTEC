//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    hw.h

Abstract:

    The main header for an Miniport driver - Hardware Related.

Notes:

--*/

#ifndef _HRD_
#define _HRD_


#define DM9000_VID		0x0A46
#define	DM9000_PID		0x9000

/********************************************************************************
 *
 * PHY Parameters
 *
 ********************************************************************************/

#define MII_INTERNAL_PHY_ADDR		1


/******************************************************************************************
 *
 * Ethernet definitions
 *
 *******************************************************************************************/

#define	DM9_MULTICAST_LIST	64
#define	MAX_MULTICAST_LIST	64

#define ETH_HEADER_SIZE     14
#define ETH_MAX_FRAME_SIZE  1514  
#define	DRIVER_BUFFER_SIZE	0x5F0  //= 1520

#define	EEPROM_SIZE	16   // WORD0~WORD7

typedef	unsigned short EEPROM_93C46_DATA_TYPE;
#define	EEPROM_DATA_TYPE	EEPROM_93C46_DATA_TYPE
	
typedef	enum {
	BYTE_MODE=1,
	WORD_MODE=2,
	DWORD_MODE=4,
} DEVICE_IO_MODE;

typedef	enum {
	DM9_NCR = 0,
	DM9_NSR,
	DM9_TXCR,
	DM9_TXSR1,
	DM9_TXSR2,
	DM9_RXCR,
	DM9_RXSR,
	DM9_ROCR,
	DM9_BACKTH,
	DM9_PAUSETH,
	DM9_FLOW,
	DM9_EPCNTL,	/* 0x0B */
	DM9_EPADDR,
	DM9_EPLOW,
	DM9_EPHIGH,
	DM9_WCR,
	
	DM9_PAR0 = 0x10,
	DM9_PAR1,
	DM9_PAR2,
	DM9_PAR3,
	DM9_PAR4,
	DM9_PAR5,

	DM9_MAR0 = 0x16,
	DM9_MAR1,
	DM9_MAR2,
	DM9_MAR3,
	DM9_MAR4,
	DM9_MAR5,
	DM9_MAR6,
	DM9_MAR7,
		
	DM9_GPCR = 0x1E,
	DM9_GPR,

	DM9_TRAL = 0x22,
	DM9_TRAH = 0x23,
	
	DM9_VIDL = 0x28,
	DM9_VIDH,
	DM9_PIDL,
	DM9_PIDH,
	
	DM9_CHIPREV = 0x2C,
	
	DM9_MRCMDX = 0xF0,
	DM9_MRCMD = 0xF2,
	DM9_MDRAH = 0xF4,
	DM9_MDRAL,
	

	DM9_MWCMDX = 0xF6,
	DM9_MWCMD = 0xF8,
	DM9_MDWAL = 0xFA,
	DM9_MDWAH = 0xFB,
	
	DM9_TXLENL = 0xFC,
	DM9_TXLENH,

	DM9_ISR = 0xFE,
	DM9_IMR
		
} DM9000_REGISTER_TYPE;

//DM9000 start ---------------------------------------------------
#define DM9000_CAST_SMODE_LINKPULSEE4	0x08	// smcr_version

#define DM9000_CAST_BUS_DRIVE	  BUS_DRIVE_8mA // 8mA is OK
#define DM9000_CAST_BUS_SPIKE	  0x0b		// pbcr_version
//DM9000 end ---------------------------------------------------

//mm2_EnhanceLink start ---------------------------------------------------
#define MIIADDR_ANAR		(4)
#define	MIIADDR_DSCR		(16)
#define	MIIADDR_SPSTAT		(17)
#define MIIADDR_SCFG		(20)
#define MIIADDR_DSP_CONTROL (27)
//mm2_EnhanceLink end -----------------------------------------------------

#endif // HRD

