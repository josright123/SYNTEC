//
// dbg.c
//
#include "precomp.h"


// dbg
BOOLEAN FindEverQOID(PNE2000_ADAPTER Adapter, NDIS_OID Oid)
{
	int i;
	for (i=0; i<Adapter->nqOID; i++)
	{
		if (Adapter->m_qOID[i]==Oid)
		{
			Adapter->m_QFindIndex= i;
			return TRUE; // "TRUE"
		}
	}
	return FALSE; // "FALSE"
}

// dbg
BOOLEAN FindEverSOID(PNE2000_ADAPTER Adapter, NDIS_OID Oid)
{
	int i;
	for (i=0; i<Adapter->nsOID; i++)
	{
		if (Adapter->m_sOID[i]==Oid)
		{
			Adapter->m_SFindIndex= i;
			return TRUE; // "TRUE"
		}
	}
	return FALSE; // "FALSE"
}

// dbg
void QSPrint(PNE2000_ADAPTER Adapter)
{
	int i, qprocess= 0, sprocess= 0;
		NKDbgPrintfW(TEXT(" "));
		for (i=0; i <Adapter->nqOID; i++)
			NKDbgPrintfW(TEXT("[%5x] "), Adapter->m_qOID[i]);
		NKDbgPrintfW(TEXT("| "));
		for (i=0; i <Adapter->nsOID; i++)
			NKDbgPrintfW(TEXT("[%5x] "), Adapter->m_sOID[i]);
		NKDbgPrintfW(TEXT("\r\n"));
		
		NKDbgPrintfW(TEXT(" "));
		for (i=0; i <Adapter->nqOID; i++)
		{
			NKDbgPrintfW(TEXT("[%5x]"), Adapter->ct_qOID[i]&0x7fff);
			if (Adapter->ct_qOID[i]&0x8000)
			{
				NKDbgPrintfW(TEXT("* "));
				qprocess++;
			}
			else
				NKDbgPrintfW(TEXT("  "));
		}
		NKDbgPrintfW(TEXT("| "));
		for (i=0; i <Adapter->nsOID; i++)
		{
			NKDbgPrintfW(TEXT("[%5x]"), Adapter->ct_sOID[i]&0x7fff);
			if (Adapter->ct_sOID[i]&0x8000)
			{
				NKDbgPrintfW(TEXT("* "));
				sprocess++;
			}
			else
				NKDbgPrintfW(TEXT("  "));
		}
		NKDbgPrintfW(TEXT("\r\n"));
			
		NKDbgPrintfW(TEXT("   "));
		NKDbgPrintfW(TEXT("Total OIDs= %d (%d), %d (%d)"), Adapter->nqOID, qprocess, Adapter->nsOID, sprocess);	
		NKDbgPrintfW(TEXT("\r\n"));
}
// dbg
void SendSetFlag(PNE2000_ADAPTER Adapter)
{
	if (!Adapter->m_PwrUntillSend)
	{
		Adapter->m_PwrUntillSend= 1;
		
		NKDbgPrintfW(TEXT("---[Print:MiniportSend]\r\n"));
		QSPrint(Adapter);
	}
}

// dbg
void CheckHangSetFlag(PNE2000_ADAPTER Adapter)
{
	if (!Adapter->m_PwrUntillChkForHang)
	{
		Adapter->m_PwrUntillChkForHang= 1;
		
		NKDbgPrintfW(TEXT("---[Print:MiniCheckForHang]\r\n"));
		QSPrint(Adapter);
	}
}


// dbg
void OnceSetInfoFlag(PNE2000_ADAPTER Adapter)
{
	if (!Adapter->m_PwrUntillOnceSetInfo)
	{
		Adapter->m_PwrUntillOnceSetInfo= 1;
		
		NKDbgPrintfW(TEXT("---[Print:OnceSetInfo]\r\n"));
		QSPrint(Adapter);
	}
}

//DBG
void PrintAdapterEEPROM(PNE2000_ADAPTER Adapter, char c)
{
	NKDbgPrintfW(TEXT("[DM9-MAC] DeviceLoadEeprom.%c--> %02x %02x %02x  %02x %02x %02x\r\n"), 
		c, Adapter->m_szEeprom[0], Adapter->m_szEeprom[1], Adapter->m_szEeprom[2],  
		Adapter->m_szEeprom[3], Adapter->m_szEeprom[4], Adapter->m_szEeprom[5]);
}
void PrintCheckEEPROM(PNE2000_ADAPTER Adapter, char c)
{
	NKDbgPrintfW(TEXT("[DM9-MAC] DeviceCheckEeprom.%c--> %02x %02x %02x  %02x %02x %02x\r\n"), 
		c, Adapter->m_szEeprom[0], Adapter->m_szEeprom[1], Adapter->m_szEeprom[2],  
		Adapter->m_szEeprom[3], Adapter->m_szEeprom[4], Adapter->m_szEeprom[5]);
}
//void PrintReadNetworkAddress(PU8 p, char c)
//{
//	NKDbgPrintfW(TEXT("[DM9-MAC] NdisReadNetworkAddress.%c--> %02x %02x %02x  %02x %02x %02x\r\n"), 
//		c, p[0], p[1], p[2],  p[3], p[4], p[5]);
//}
void PrintNdisReadNetAddrToEEPROM(PNE2000_ADAPTER Adapter, char c)
{
	NKDbgPrintfW(TEXT("[DM9-MAC] NdisReadNetworkAddress.%c--> %02x %02x %02x  %02x %02x %02x\r\n"), 
		c, Adapter->m_szEeprom[0], Adapter->m_szEeprom[1], Adapter->m_szEeprom[2],  
		Adapter->m_szEeprom[3], Adapter->m_szEeprom[4], Adapter->m_szEeprom[5]);
}

//DBG
void PrintChipPAR(PNE2000_ADAPTER Adapter, char *str)
{
	int n;
	NKDbgPrintfW(TEXT("[dm9] -- [PAR %s]="), str);
	// show node address in chip
	for(n=0;n<ETH_ADDRESS_LENGTH;n++)
		NKDbgPrintfW(TEXT(" %02x"), DeviceReadPort(Adapter,DM9_PAR0+n));
	NKDbgPrintfW(TEXT(" ..\r\n"));
}
void PrintChipMDWARA(PNE2000_ADAPTER Adapter, char *str)
{
	NKDbgPrintfW(TEXT("[dm9] -- [MDWARA %s] DM9_MDWAH= %02x -- \r\n"), str, DeviceReadPort(Adapter, 0xFB));
	NKDbgPrintfW(TEXT("[dm9] -- [MDWARA %s] DM9_MDWAL= %02x -- \r\n"), str, DeviceReadPort(Adapter, 0xFA));

	NKDbgPrintfW(TEXT("[dm9] -- [MDWARA %s] DM9_MDRAL= %02x -- \r\n"), str, DeviceReadPort(Adapter, 0xF5));
	NKDbgPrintfW(TEXT("[dm9] -- [MDWARA %s] DM9_MDRAH= %02x -- \r\n"), str, DeviceReadPort(Adapter, 0xF4));
}



//DBG
void PrintMoveMem(NDIS_OID Oid, ULONG BytesWritten, PU8 dat)
{
	ULONG i;
		QMVPrint(TEXT("<%6x>>> LEN %d ="), Oid, BytesWritten); 
		for (i=0; i<BytesWritten; i++) 
		{
			QMVPrint(TEXT(" %02x"), *((PU8)dat+i)); 
		}
		QMVPrint(TEXT("\r\n"));
}
//DBG
void PrintTxHead(int BytesPrinted, PU8 dat)
{
	int i;
		TXPrint(TEXT("[dm9tx]="));
		for (i=0; i<BytesPrinted; i++) 
		{
			if ((i%8)==0) TXPrint(TEXT("  "));
			if (i && (i%16)==0) TXPrint(TEXT("\r\n"));
			TXPrint(TEXT("%02x "), *((PU8)dat+i)); 
			//NKDbgPrintfW(TEXT("%02x "), *((PU8)dat+i));  //OK
		}
		TXPrint(TEXT(" ..\r\n"));
}