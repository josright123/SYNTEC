// id_custom_enum.c

#include <windows.h>
//#include <bsp.h>    // for ..
//#include <register_map.h>  // Update Rollup ... !

#include "precomp.h"


#if 1
	void ID_Custom_Init(void)
	{
	}
#elif 0
	volatile PSROMCON_REG sv210SROM;    
	volatile PGPIO_REG gS5PV210_pGPIOReg; 
	void ID_Custom_Init(void)
	{
	//
	//  CS1, EINT10
	//
	// [Customization: Of UT-V210 ]
	PHYSICAL_ADDRESS ioPhysicalSROM = {0, 0};
	PHYSICAL_ADDRESS ioPhysicalBase = {0, 0};

	ioPhysicalSROM.LowPart = BASE_REG_PA_SROM;
	sv210SROM= MmMapIoSpace(ioPhysicalSROM, sizeof(SROMCON_REG), FALSE);
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [SROM->SROM_BW] %x]\r\n"), sv210SROM->SROM_BW); // bit[7:4]= 0001b = 16-bit
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [SROM->SROM_BC1] %x]\r\n"), sv210SROM->SROM_BC1); //= ((0<<28)|(0<<24)|(5<<16)|(0<<12)|(0<<8)|(0<<4)|(0<<0)) 

	ioPhysicalBase.LowPart = BASE_REG_PA_GPIO;
	gS5PV210_pGPIOReg= MmMapIoSpace(ioPhysicalBase, sizeof(GPIO_REG), FALSE);
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [data MP_CON] %x]\r\n"), gS5PV210_pGPIOReg->MP0_1.MP_CON); // bit[7:4]= 0010b= SROM_CSn[1]
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [data GP_H1_CON] %x]\r\n"), gS5PV210_pGPIOReg->GPH1.GP_CON );  // (NEED 0xC20) bit[11:8]= 1111b= EINT[10]
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [data EI1C] %x]\r\n"), gS5PV210_pGPIOReg->EINTCON.EXT_INT1_CON );  // 0xE00 ~ 0xE0C (need 0xE04) // bit[10:8]= 1b= High level 
	}
#else
	volatile PGPIO_REG gS5PV210_pGPIOReg;  //PSXXXXXX_GPIO_REG
	volatile PSROMCON_REG sv210SROM;       //SROMCON_REG, *PSROMCON_REG;
	void ID_Custom_Init(void)
	{
	//
	//  CS4, EINT9
	//
	// [Customization: Add for V210 ]
	PHYSICAL_ADDRESS ioPhysicalSROM = {0, 0};
	PHYSICAL_ADDRESS ioPhysicalBase = {0, 0};
//S5PV210 -CPU_Memory Bank5 - Device_IOTiming
	ioPhysicalSROM.LowPart = BASE_REG_PA_SROM;
	sv210SROM= MmMapIoSpace(ioPhysicalSROM, sizeof(SROMCON_REG), FALSE);
//[sv210SROM]
//	  sv210SROM->SROM_BW= (sv210SROM->SROM_BW & ~0x00f00000) | (0x3<<20); // CS5
	  sv210SROM->SROM_BW= (sv210SROM->SROM_BW & ~0x000f0000) | (0x3<<16); // CS4
	  sv210SROM->SROM_BW= (sv210SROM->SROM_BW & ~0x000f0000) | (0x1<<16); // CS4
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: sv210SROM->SROM_BW %x]\r\n"), sv210SROM->SROM_BW);
	//S5PV210 -CPU_Memory Bank5 - Data bus width
//    sv210SROM->SROM_BC4= ((10<<28)|(10<<24)|(0x1f<<16)|(10<<12)|(10<<8)|(10<<4)|(0<<0)); For -ONYX210
	  sv210SROM->SROM_BC4= ((0<<28)|(0<<24)|(5<<16)|(0<<12)|(0<<8)|(0<<4)|(0<<0)); // For -Urbetter V210. Used for ONYX210
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: sv210SROM->SROM_BC4 %x]\r\n"), sv210SROM->SROM_BC4);
	// GPIO Virtual alloc (S5PV210)
	ioPhysicalBase.LowPart = BASE_REG_PA_GPIO;
	gS5PV210_pGPIOReg= MmMapIoSpace(ioPhysicalBase, sizeof(GPIO_REG), FALSE);
//	  gS5PV210_pGPIOReg->MP0_1.MP_CON= (gS5PV210_pGPIOReg->MP0_1.MP_CON & ~0x00f00000) | (0x2<<20); // CS5 Sel SROM_CSn[5] func
	  gS5PV210_pGPIOReg->MP0_1.MP_CON= (gS5PV210_pGPIOReg->MP0_1.MP_CON & ~0x000f0000) | (0x2<<16); // CS4 Sel SROM_CSn[4] func
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: pGPIOregs->MP0_1.MP_CON %x]\r\n"), gS5PV210_pGPIOReg->MP0_1.MP_CON);
// ... Interrupt Configuration~
// (1) GP_H1_CON
// (2) EXT_INT_1_CON (EI1C)
	gS5PV210_pGPIOReg->GPH1.GP_CON= (gS5PV210_pGPIOReg->GPH1.GP_CON & ~(0xf << 4)) | (0xf<< 4); // 1111b= EXT_INT[9]
	gS5PV210_pGPIOReg->EINTCON.EXT_INT1_CON= (gS5PV210_pGPIOReg->EINTCON.EXT_INT1_CON & ~(0x7 << 4)) | (0x1 << 4); // 1b= High level 
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [data GP_H1_CON] %x]\r\n"), gS5PV210_pGPIOReg->GPH1.GP_CON );  // (NEED 0xC20)
	NKDbgPrintfW(TEXT("[DM9000B.S5PV210.chk: [data EI1C] %x]\r\n"), gS5PV210_pGPIOReg->EINTCON.EXT_INT1_CON );  // 0xE00 ~ 0xE0C (need 0xE04)
	}
#endif