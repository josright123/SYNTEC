* V3.00, The stable function with customization definition.
* V3.03, Spike enhance function, DONE.
* V3.05, Add the registry file (TARGETNAME=dm9000n, TARGETTYPE=DYNLINK, for dm9000n.dll)
* V3.06, Add 'OID_802_3_PERMANENT_ADDRESS' support, in DriverQueryInformation()
* V3.07, Revise "sources" for CE7.0