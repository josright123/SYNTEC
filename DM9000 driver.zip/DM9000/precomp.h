//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
#include <ndis.h>

//#define IMPL_SEND_INDICATION (Cancel)     // Use NDIS_STATUS_PENDING, + MSend Complete

// Behavior Selections
#define SEND_INT_TXEND_RSRC		1	// must INT 
#define SEND_WAIT_TXCMPLT		2   // not INT 

//*******************************************************************************
//
// Driver behaviors
// 
//*******************************************************************************
#define	IMPL_STATISTICS
#define	REPORT(adptr, evt,val)	DeviceReportStatistics(adptr, evt,val)
#define DM9000_IMPL_SEND	SEND_WAIT_TXCMPLT

// "const"
#define BUS_DRIVE_2mA	0x01		// 2mA
#define BUS_DRIVE_4mA	0x21		// 4mA
#define BUS_DRIVE_8mA	0x61		// 8mA

#define INT_ACTIVE_HIGH	0x00		// Active High
#define INT_ACTIVE_LOW	0x01		// Active Low

#include "ver.h"
#include "dbg.h"
#include "hw.h"
#include "sw.h"





