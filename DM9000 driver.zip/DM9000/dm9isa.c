
#include "precomp.h"
#include <ceddk.h>
#include "common_ddk.h"

#define	ENTER_CRITICAL_SECTION	NdisAcquireSpinLock(&Adapter->m_spinAccessToken); 
#define	LEAVE_CRITICAL_SECTION	NdisReleaseSpinLock(&Adapter->m_spinAccessToken);

#define	BSP_ARGS_RAM_START			( 0x80001000 )
#define	BSP_MAC2_ARGS_SHIFT			( 0x54 )


U32	DeviceReadPort(
	PNE2000_ADAPTER Adapter,
	U32		uPort)
{
	U16		val;

	ENTER_CRITICAL_SECTION  //NdisAcquireSpinLock(&Adapter->xxxLockToken);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 0);		//&*&*J1_add
    NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS], uPort);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 1);		//&*&*J1_add
	NdisRawReadPortUchar(  Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, &val);
	LEAVE_CRITICAL_SECTION  //NdisReleaseSpinLock(&Adapter->xxxLockToken);
	
	return (U32)val;
}

U32	DeviceWritePort(
	PNE2000_ADAPTER Adapter, 
	U32 uPort, 
	U32 uValue)
{
	ENTER_CRITICAL_SECTION  //NdisAcquireSpinLock(&Adapter->xxxLockToken);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 0);		//&*&*J1_add
    NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS], uPort);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 1);		//&*&*J1_add
    NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, uValue);
	LEAVE_CRITICAL_SECTION  //NdisReleaseSpinLock(&Adapter->xxxLockToken);
	return uValue;
}

BOOLEAN DevicePolling(
    PNE2000_ADAPTER Adapter,
	U32		uPort,
	U32		uMask,
	U32		uExpected,
	U32		uInterval,	/* in millisecond */
	U32		uRetries)
{
	for(;uRetries;uRetries--)
	{
		if((DeviceReadPort(Adapter,uPort) & uMask) == uExpected) break;
		NdisStallExecution(uInterval);
	} // of retry loop
	
	return (BOOLEAN)uRetries; // (BOOL)uRetries;
}


U16	DeviceWritePhy(
	PNE2000_ADAPTER Adapter, 
	U32		uOffset,
	U16		uValue)
{
	// assign the phy register offset, internal phy(0x40) plus phy offset
	DeviceWritePort(Adapter, DM9_EPADDR,(0x40|(uOffset&0x3F)));

	// put data
	DeviceWritePort(Adapter, DM9_EPLOW, LOW_BYTE(uValue));
	DeviceWritePort(Adapter, DM9_EPHIGH,HIGH_BYTE(uValue));

	// issue PHY select<3> and write command<1>
	DeviceWritePort(Adapter, DM9_EPCNTL,((1<<3)|(1<<1)) );
	
	// wait until status bit<0> cleared
	NdisStallExecution(50);
	NdisStallExecution(50);
	NdisStallExecution(50);
	NdisStallExecution(50);
	
	// stop command
	DeviceWritePort(Adapter, DM9_EPCNTL,0);

	return uValue;
}

//"dm9isa"
U32 DeviceReadDataWithoutIncrement(PNE2000_ADAPTER Adapter)
{
	U32		value,tmp;

  	ENTER_CRITICAL_SECTION
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 0);		//&*&*J1_add
    NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS], DM9_MRCMDX);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 1);		//&*&*J1_add
    value = 0; //&*&*&J1_add

	switch (Adapter->m_nIoMode)
	{
		case BYTE_MODE:
			NdisRawReadPortUchar(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU8)&tmp);
			NdisRawReadPortUchar(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU8)&value);
			value = (value&0x000000FF);
			break;

		case WORD_MODE:
			NdisRawReadPortUshort(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU16)&tmp);
			NdisRawReadPortUshort(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU16)&value);
			value = (value&0x0000FFFF);
			break;
				
		case DWORD_MODE:
			NdisRawReadPortUlong(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU32)&tmp);
			NdisRawReadPortUlong(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] 
				+ DM9000_CAST_DATA_OFFSET, (PU32)&value);
			break;
				
		default:
			break;
	} // of switch
  	LEAVE_CRITICAL_SECTION

	return value;
}

void DeviceEnableInterrupt(PNE2000_ADAPTER Adapter)
{
	// bits to turn on interrupt latch
	// <7> buffer chain enable
	// <3> rx overflow count overflow
	// <2> rx overflow
	// <1> tx completed indication
	// <0> rx completed indication
	U32		val;
	val = DeviceReadPort(Adapter, DM9_IMR);
	
	//ISRPrint (TEXT("[**DM9-EnableIINT**]..\r\n")); // [DM9000B]
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. 1.s 0x%02x\r\n"), val);
//	DeviceWritePort(Adapter, DM9_IMR,((1<<7)|(1<<3)|(1<<2)|(1<<1)|(1<<0)));
	DeviceWritePort(Adapter, DM9_IMR,((1<<7)|(1<<3)|(1<<2)|(5<<1)|(1<<0)));
//	DeviceWritePort(Adapter, DM9_IMR,((1<<7)));
	
	
	val = DeviceReadPort(Adapter, DM9_IMR);
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. 1.e 0x%02x\r\n"), val);
}

void DeviceDisableInterrupt(PNE2000_ADAPTER Adapter)
{
	// <7> buffer chain enable
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. DeviceDisableInterrupt\r\n"));
	ISRPrint (TEXT("[**DM9-DisableINT**]..\r\n")); // [DM9000B]
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. 2.S\r\n"));
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. 2\r\n"));
	
	DeviceWritePort(Adapter, DM9_IMR, (1<<7));
//	    NKDbgPrintfW(TEXT("[dm9] -- Jeffrey .. isr  .. 2.E\r\n"));
}

//----------------------------------------- tmp -------------------------------------------------

U16	DeviceReadEeprom(PNE2000_ADAPTER Adapter, U32 uWordAddress)
{
	U16		highbyte,lowbyte;
	
	// assign the register offset
	DeviceWritePort(Adapter, DM9_EPADDR,uWordAddress);
	
	// issue EEPROM read command<2>
	DeviceWritePort(Adapter, DM9_EPCNTL,(1<<2));
	
	// wait until status bit<0> cleared
	// 80 uS, 5 times
	if(!DevicePolling(Adapter, DM9_EPCNTL,(1<<0),0x00,80,5))
		return (U16)-1;
	
	// stop command
	DeviceWritePort(Adapter, DM9_EPCNTL,0);

	// retrive data
	lowbyte  = (U16)DeviceReadPort(Adapter, DM9_EPLOW);
	highbyte = (U16)DeviceReadPort(Adapter, DM9_EPHIGH);
	
	return ((highbyte<<8) | lowbyte);
}

void EDeviceLoadEeprom(PNE2000_ADAPTER Adapter)
{
	int n;
	EEPROM_DATA_TYPE *pcurr=(EEPROM_DATA_TYPE*)&Adapter->m_szEeprom[0];

        PrintAdapterEEPROM(Adapter,'s');
		
	for(n=0;n<(DIM(Adapter->m_szEeprom)/sizeof(EEPROM_DATA_TYPE));n++,pcurr++)
	{
		*pcurr = DeviceReadEeprom(Adapter, n);

	} // of for offset n

        PrintAdapterEEPROM(Adapter,'e');
}

void LoadMacFromRAM(PNE2000_ADAPTER Adapter)
// load MAC from ARGS on RAM
{
	struct MAC_ADDR_ARGS *MAC2_ARGS; 
	MAC2_ARGS = (struct MAC_ADDR_ARGS *)(BSP_ARGS_RAM_START + BSP_MAC2_ARGS_SHIFT);

	// IQC did NOT set MAC2, give the MAC2 a compatible default.
	if ( (MAC2_ARGS->mac[0] == 0) && (MAC2_ARGS->mac[1] == 0) && (MAC2_ARGS->mac[2] == 0) )
	{
		MAC2_ARGS->mac[0] = 0x6000;
		MAC2_ARGS->mac[1] = 0x006E;
		MAC2_ARGS->mac[2] = 0x00FF;
	}

	Adapter->m_szEeprom[0]= MAC2_ARGS->mac[0] & 0x00FF;
	Adapter->m_szEeprom[1]= MAC2_ARGS->mac[0] >> 8;
	Adapter->m_szEeprom[2]= MAC2_ARGS->mac[1] & 0x00FF;
	Adapter->m_szEeprom[3]= MAC2_ARGS->mac[1] >> 8;
	Adapter->m_szEeprom[4]= MAC2_ARGS->mac[2] & 0x00FF;
	Adapter->m_szEeprom[5]= MAC2_ARGS->mac[2] >> 8;

}

void EDeviceCheckEeprom(PNE2000_ADAPTER Adapter)
{	
  //U32 uWordAddress;
	//U16 eeprom[] = { 0x0060,0x6e00,0xff00 };
//----------------------------------------------	
	//U16 eeprom[] = { 0x1122,0x3344,0x5566,0x5445,0x0a46,0x9000,0x01e7,0x4180};
  //U16 eeprom[] = { 0xaae0,0xdec8,0x5163,0x5445,0x0a46,0x9000,0x01e7,0x4180};
  //U16 eeprom[] = { 0xffba,0x5de3,0x82c6};
  
#if STATIC_MAC_ADDR  
  
       PrintCheckEEPROM(Adapter, 's');
/*  
  if (ValidateMACAddr()) return;
*/  
   //U8
   //Adapter->m_szEeprom[0]= STATIC_ADDR0 | STATIC_ADDR1 <<8;
   //Adapter->m_szEeprom[1]= STATIC_ADDR2 | STATIC_ADDR3 <<8;
   //Adapter->m_szEeprom[2]= STATIC_ADDR4 | STATIC_ADDR5 <<8;
	Adapter->m_szEeprom[0]= STATIC_ADDR0;
	Adapter->m_szEeprom[1]= STATIC_ADDR1;
	Adapter->m_szEeprom[2]= STATIC_ADDR2;
	Adapter->m_szEeprom[3]= STATIC_ADDR3;
	Adapter->m_szEeprom[4]= STATIC_ADDR4;
	Adapter->m_szEeprom[5]= STATIC_ADDR5;

       PrintCheckEEPROM(Adapter, 'e');
#endif 
	//if( uWordAddress < sizeof( eeprom ) )
	//	return eeprom[uWordAddress];
	//else
	//	return 0;
//----------------------------------------------
}

U8 *DeviceMacAddress(PNE2000_ADAPTER Adapter, U8 *ptrBuffer)
{
	PU16	pcurr;
	if(!ptrBuffer) return ptrBuffer;

	pcurr=(PU16)&Adapter->m_szEeprom[0];
	*(PU16)ptrBuffer = *pcurr++;
	*(PU16)(ptrBuffer+2) = *pcurr++;
	*(PU16)(ptrBuffer+4) = *pcurr++;
	return ptrBuffer;
}

//
// Alignment aware wrapper for NdisRawWriteBufferUshort
//
void
DM9000RawWritePortBufferUshort(
    DWORD dwIoPort,
    PUSHORT pBuf,
    DWORD   cWords
    )
{
    PUCHAR pch;
    PUCHAR pchTmp;
    USHORT usTmp;

    if ((DWORD)pBuf & 1) {
        NKDbgPrintfW(TEXT("[DM9000RawWritePortBufferUshort] - unaligned buffer in 16 bit mode!\r\n"));

        pch = (PUCHAR)pBuf;
        pchTmp = (PUCHAR)&usTmp;

        while (cWords) {
            pchTmp[0] = pch[0];
            pchTmp[1] = pch[1];
            pch += 2;
            NdisRawWritePortUshort(dwIoPort, usTmp);
            cWords--;
        }
    } else {
        NdisRawWritePortBufferUshort(dwIoPort, pBuf, cWords);
    }
}   // DM9000RawWritePortBufferUshort

//
// Alignment aware wrapper for NdisRawReadBufferUshort
//
void
DM9000RawReadPortBufferUshort(
    DWORD dwIoPort,
    PUSHORT pBuf,
    DWORD   cWords
    )
{
    PUCHAR pch;
    PUCHAR pchTmp;
    USHORT usTmp;

    if ((DWORD)pBuf & 1) {
        NKDbgPrintfW(TEXT("DM9000RawReadPortBufferUshort - unaligned buffer in 16 bit mode!\r\n"));

        pch = (PUCHAR)pBuf;
        pchTmp = (PUCHAR)&usTmp;

        while (cWords) {
            NdisRawReadPortUshort(dwIoPort, &usTmp);
            pch[0] = pchTmp[0];
            pch[1] = pchTmp[1];
            pch += 2;
            cWords--;
        }
    } else {
        NdisRawReadPortBufferUshort(dwIoPort, pBuf, cWords);
    }
}   // DM9000RawReadPortBufferUshort

PU8 DeviceWriteString(
	PNE2000_ADAPTER Adapter, 
	PU8		ptrBuffer,
	int		nLength)
{
	int		count;
	count = (nLength + Adapter->m_nIoMaxPad) / Adapter->m_nIoMode;
	
	// select port to be read from

	ENTER_CRITICAL_SECTION
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 0);		//&*&*J1_add
	NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS], DM9_MWCMD);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 1);		//&*&*J1_add
	switch (Adapter->m_nIoMode)
	{
		case BYTE_MODE:
			NdisRawWritePortBufferUchar(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				ptrBuffer,count);
			break;
			
		case WORD_MODE:
			DM9000RawWritePortBufferUshort(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				(PU16)ptrBuffer,count);
			break;

		case DWORD_MODE:
			NdisRawWritePortBufferUlong(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				(PU32)ptrBuffer,count);
			break;
		
		default:
			break;
	} // of switch
	LEAVE_CRITICAL_SECTION

	//if (Adapter->m_nIoMode==WORD_MODE) TXPrint(TEXT("   [MiniportSend] -------- [WriteString] 16-bit mode --\r\n"));

	return ptrBuffer;
}

PU8	DeviceReadString(
	PNE2000_ADAPTER Adapter, 
	PU8		ptrBuffer,
	int		nLength)
{
	int		count;
	
	count = (nLength + Adapter->m_nIoMaxPad) / Adapter->m_nIoMode;

	// select port to be read from

	ENTER_CRITICAL_SECTION
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 0);		//&*&*J1_add
	NdisRawWritePortUchar( Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS], DM9_MRCMD);
    DDKGpioWriteDataPin(DDK_GPIO_PORT5, 17, 1);		//&*&*J1_add
	switch (Adapter->m_nIoMode)
	{
		case BYTE_MODE:
			NdisRawReadPortBufferUchar(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				ptrBuffer,count);
			break;
			
		case WORD_MODE:
			DM9000RawReadPortBufferUshort(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				(PU16)ptrBuffer,count);
			break;

		case DWORD_MODE:
			NdisRawReadPortBufferUlong(
				Adapter->m_szCurrentSettings[SID_PORT_BASE_ADDRESS] + DM9000_CAST_DATA_OFFSET, 
				(PU32)ptrBuffer,count);
			break;
		
		default:
			break;
	} // of switch
	LEAVE_CRITICAL_SECTION

	return ptrBuffer;
}	