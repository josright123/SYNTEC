

#ifndef _VER_
#define _VER_
#include <csp.h>


	#define DRIVER_VERSION	_T("V3.07")

// V210
	#define CUSTOM_BOARD_STR  _T("CUSTOM_SMDK1 V210 (2011 June)")
	
//ONYX210
	//#define DM9000_CAST_IO_ADDRESS    0xA0000000 //CS4
	//#define	DM9000_CAST_DATA_OFFSET	  0x02 //0x1 //ADDR0  //0x04	//0x02//0x04//0x08, SMDK
	//#define DM9000_CAST_IRQ_NUMBER	  9  //10   //4	
//UTV210
//	#define DM9000_CAST_IO_ADDRESS    0x08000000 // CS0 //0x18000000 //88000000 //CS1		//&*&*&J1_mod
	#define DM9000_CAST_IO_ADDRESS    0x0C000000 // CS0 //0x18000000 //88000000 //CS1		//&*&*&J1_mod
	#define	DM9000_CAST_DATA_OFFSET	  0x04 //0x1 //ADDR0  //0x02 //0x08, SMDK
//	#define DM9000_CAST_IRQ_NUMBER	  ( 3 << 5 | 21 ) //58 //23  //gpio1_26
//	#define DM9000_CAST_IRQ_NUMBER	  (( 1 << 5 ) | 26 ) //58 //23  //gpio1_26
	#define DM9000_CAST_IRQ_NUMBER	  IRQ_GPIO6_PIN11 // 331 //171 //186 //(( 0 << 5 ) | 19 ) //58 //23  //gpio1_26
//	#define DM9000_CAST_IRQ_NUMBER	  (( 0 << 5 ) | 19 ) //58 //23  //gpio1_26
//DM9000 start ---------------------------------------------------
	#define DM9000_CAST_INT			  INT_ACTIVE_HIGH //INT_ACTIVE_LOW //INT_ACTIVE_HIGH
//DM9000 end ---------------------------------------------------

// MacAddrDefinition
#define NE2000_LENGTH_OF_ADDRESS 6  // Size of the ethernet address
#define ETH_ADDRESS_LENGTH  6
// AddrData
#define STATIC_MAC_ADDR	1
#define STATIC_ADDR0	0x00  //0xba//
#define STATIC_ADDR1	0x60  //0xff//
#define STATIC_ADDR2	0x6e  //0xe3//
#define STATIC_ADDR3	0x00  //0x5d//
#define STATIC_ADDR4	0xff  //0xc6//
#define STATIC_ADDR5	0x00  //0x82//

#endif // VER

