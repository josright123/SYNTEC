//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

wince.c

Abstract:  

Windows CE specific functions for the NE2000 NDIS miniport driver.

Functions:
    DllEntry
    AddKeyValues
    Install_Driver
    FindDetectKey
    DetectNE2000


Notes: 


--*/

#include <ndis.h>



//
// Standard Windows DLL entrypoint.
// Since Windows CE NDIS miniports are implemented as DLLs, a DLL entrypoint is
// needed.
//
BOOL __stdcall
DllEntry(
  HANDLE hDLL,
  DWORD dwReason,
  LPVOID lpReserved
)
{

    switch (dwReason) {
    case DLL_PROCESS_ATTACH:
        //DEBUGREGISTER(hDLL);
        //DEBUGMSG(ZONE_INIT, (TEXT("NE2000: DLL_PROCESS_ATTACH\n")));
				DisableThreadLibraryCalls((HMODULE) hDLL);
        break;
    case DLL_PROCESS_DETACH:
    default:
        break;
    }
    return TRUE;
}
