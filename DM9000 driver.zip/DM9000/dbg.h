//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    dbg.h

Abstract:

    Dbg switch.

Notes:

--*/

#ifndef _DBG_
#define _DBG_

//#define ARGS(x) (#x)
//#define	TO_PRINT(fmt, args...)	NKDbgPrintfW(fmt, ##args)
//#define	NOT_PRINT(fmt, args...)

//selection
#define	TO_PRINT	NKDbgPrintfW
#define	NOT_PRINT(fmt)
#define EMPTY_PRINT

//definition
#define	QPrint(msg, ...) EMPTY_PRINT
#define	QMVPrint(msg, ...) EMPTY_PRINT 
//#define	TXPrint  NKDbgPrintfW
  #define	TXPrint  
#define	RXPrint(msg, ...) NOT_PRINT(msg)
#define	ISRPrint(fmt, ...) NOT_PRINT(fmt)
#define ThreeCntrPrint(msg, ...) NOT_PRINT(msg)

#endif // DBG

